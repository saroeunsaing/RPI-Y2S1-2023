﻿namespace RPITST_Dashboard
{
    partial class Frm_Level
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_Content = new System.Windows.Forms.Panel();
            this.Btn_Delete = new FontAwesome.Sharp.IconButton();
            this.Btn_Edit = new FontAwesome.Sharp.IconButton();
            this.Btn_Save = new FontAwesome.Sharp.IconButton();
            this.DGV_Data = new System.Windows.Forms.DataGridView();
            this.Txt_Description = new System.Windows.Forms.TextBox();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Txt_NameEN = new System.Windows.Forms.TextBox();
            this.name = new FontAwesome.Sharp.IconButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Txt_level = new System.Windows.Forms.TextBox();
            this.level = new FontAwesome.Sharp.IconButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Txt_ID = new System.Windows.Forms.TextBox();
            this.ID = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Close = new FontAwesome.Sharp.IconButton();
            this.panel_Content.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Content
            // 
            this.panel_Content.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel_Content.Controls.Add(this.Btn_Delete);
            this.panel_Content.Controls.Add(this.Btn_Edit);
            this.panel_Content.Controls.Add(this.Btn_Save);
            this.panel_Content.Controls.Add(this.DGV_Data);
            this.panel_Content.Controls.Add(this.Txt_Description);
            this.panel_Content.Controls.Add(this.iconButton4);
            this.panel_Content.Controls.Add(this.panel4);
            this.panel_Content.Controls.Add(this.Txt_NameEN);
            this.panel_Content.Controls.Add(this.name);
            this.panel_Content.Controls.Add(this.panel3);
            this.panel_Content.Controls.Add(this.Txt_level);
            this.panel_Content.Controls.Add(this.level);
            this.panel_Content.Controls.Add(this.panel2);
            this.panel_Content.Controls.Add(this.Txt_ID);
            this.panel_Content.Controls.Add(this.ID);
            this.panel_Content.Controls.Add(this.panel1);
            this.panel_Content.Controls.Add(this.label1);
            this.panel_Content.Controls.Add(this.Btn_Close);
            this.panel_Content.Location = new System.Drawing.Point(0, 0);
            this.panel_Content.Name = "panel_Content";
            this.panel_Content.Size = new System.Drawing.Size(800, 600);
            this.panel_Content.TabIndex = 0;
            this.panel_Content.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Content_Paint);
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.FlatAppearance.BorderSize = 0;
            this.Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Delete.ForeColor = System.Drawing.Color.DarkRed;
            this.Btn_Delete.IconChar = FontAwesome.Sharp.IconChar.TrashAlt;
            this.Btn_Delete.IconColor = System.Drawing.Color.DarkRed;
            this.Btn_Delete.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Delete.IconSize = 30;
            this.Btn_Delete.Location = new System.Drawing.Point(614, 228);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(174, 35);
            this.Btn_Delete.TabIndex = 20;
            this.Btn_Delete.Text = "លុប | Delete";
            this.Btn_Delete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Delete.UseVisualStyleBackColor = true;
            // 
            // Btn_Edit
            // 
            this.Btn_Edit.FlatAppearance.BorderSize = 0;
            this.Btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Edit.ForeColor = System.Drawing.Color.DarkRed;
            this.Btn_Edit.IconChar = FontAwesome.Sharp.IconChar.PenToSquare;
            this.Btn_Edit.IconColor = System.Drawing.Color.DarkRed;
            this.Btn_Edit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Edit.IconSize = 30;
            this.Btn_Edit.Location = new System.Drawing.Point(614, 181);
            this.Btn_Edit.Name = "Btn_Edit";
            this.Btn_Edit.Size = new System.Drawing.Size(174, 35);
            this.Btn_Edit.TabIndex = 19;
            this.Btn_Edit.Text = "កែប្រែ | Edit";
            this.Btn_Edit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Edit.UseVisualStyleBackColor = true;
            this.Btn_Edit.Click += new System.EventHandler(this.iconButton6_Click);
            // 
            // Btn_Save
            // 
            this.Btn_Save.FlatAppearance.BorderSize = 0;
            this.Btn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Save.ForeColor = System.Drawing.Color.DarkRed;
            this.Btn_Save.IconChar = FontAwesome.Sharp.IconChar.FloppyDisk;
            this.Btn_Save.IconColor = System.Drawing.Color.DarkRed;
            this.Btn_Save.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Save.IconSize = 30;
            this.Btn_Save.Location = new System.Drawing.Point(614, 140);
            this.Btn_Save.Name = "Btn_Save";
            this.Btn_Save.Size = new System.Drawing.Size(174, 35);
            this.Btn_Save.TabIndex = 18;
            this.Btn_Save.Text = "រក្សាទុក | Save";
            this.Btn_Save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Save.UseVisualStyleBackColor = true;
            this.Btn_Save.Click += new System.EventHandler(this.iconButton5_Click);
            // 
            // DGV_Data
            // 
            this.DGV_Data.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DGV_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Data.GridColor = System.Drawing.Color.WhiteSmoke;
            this.DGV_Data.Location = new System.Drawing.Point(3, 301);
            this.DGV_Data.Name = "DGV_Data";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Suwannaphum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Data.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_Data.RowHeadersWidth = 51;
            this.DGV_Data.Size = new System.Drawing.Size(794, 296);
            this.DGV_Data.TabIndex = 17;
            // 
            // Txt_Description
            // 
            this.Txt_Description.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Txt_Description.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_Description.ForeColor = System.Drawing.Color.DimGray;
            this.Txt_Description.Location = new System.Drawing.Point(91, 239);
            this.Txt_Description.Name = "Txt_Description";
            this.Txt_Description.Size = new System.Drawing.Size(500, 37);
            this.Txt_Description.TabIndex = 16;
            this.Txt_Description.Text = "ពិពណ៌នា";
            // 
            // iconButton4
            // 
            this.iconButton4.FlatAppearance.BorderSize = 0;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.ListUl;
            this.iconButton4.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 25;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.Location = new System.Drawing.Point(65, 247);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(25, 25);
            this.iconButton4.TabIndex = 15;
            this.iconButton4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.iconButton4.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Red;
            this.panel4.Location = new System.Drawing.Point(65, 277);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(525, 2);
            this.panel4.TabIndex = 14;
            // 
            // Txt_NameEN
            // 
            this.Txt_NameEN.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Txt_NameEN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_NameEN.ForeColor = System.Drawing.Color.DimGray;
            this.Txt_NameEN.Location = new System.Drawing.Point(89, 183);
            this.Txt_NameEN.Name = "Txt_NameEN";
            this.Txt_NameEN.Size = new System.Drawing.Size(500, 37);
            this.Txt_NameEN.TabIndex = 13;
            this.Txt_NameEN.Text = "ជាឡាំង";
            // 
            // name
            // 
            this.name.FlatAppearance.BorderSize = 0;
            this.name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.name.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.name.IconChar = FontAwesome.Sharp.IconChar.Font;
            this.name.IconColor = System.Drawing.Color.DarkRed;
            this.name.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.name.IconSize = 25;
            this.name.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.name.Location = new System.Drawing.Point(63, 191);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(25, 25);
            this.name.TabIndex = 12;
            this.name.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.name.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Location = new System.Drawing.Point(63, 221);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(525, 2);
            this.panel3.TabIndex = 11;
            // 
            // Txt_level
            // 
            this.Txt_level.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Txt_level.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_level.ForeColor = System.Drawing.Color.DimGray;
            this.Txt_level.Location = new System.Drawing.Point(90, 131);
            this.Txt_level.Name = "Txt_level";
            this.Txt_level.Size = new System.Drawing.Size(500, 37);
            this.Txt_level.TabIndex = 10;
            this.Txt_level.Text = "កម្រិតសិក្សា";
            // 
            // level
            // 
            this.level.FlatAppearance.BorderSize = 0;
            this.level.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.level.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.level.IconChar = FontAwesome.Sharp.IconChar.Keyboard;
            this.level.IconColor = System.Drawing.Color.DarkRed;
            this.level.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.level.IconSize = 25;
            this.level.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.level.Location = new System.Drawing.Point(64, 139);
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(25, 25);
            this.level.TabIndex = 9;
            this.level.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.level.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(64, 169);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(525, 2);
            this.panel2.TabIndex = 8;
            // 
            // Txt_ID
            // 
            this.Txt_ID.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Txt_ID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_ID.ForeColor = System.Drawing.Color.DimGray;
            this.Txt_ID.Location = new System.Drawing.Point(92, 80);
            this.Txt_ID.Name = "Txt_ID";
            this.Txt_ID.Size = new System.Drawing.Size(500, 37);
            this.Txt_ID.TabIndex = 7;
            this.Txt_ID.Text = "លេខសម្គាល់";
            // 
            // ID
            // 
            this.ID.FlatAppearance.BorderSize = 0;
            this.ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ID.IconChar = FontAwesome.Sharp.IconChar.IdBadge;
            this.ID.IconColor = System.Drawing.Color.DarkRed;
            this.ID.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.ID.IconSize = 25;
            this.ID.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ID.Location = new System.Drawing.Point(66, 87);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(25, 25);
            this.ID.TabIndex = 6;
            this.ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ID.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(66, 117);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(525, 2);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Suwannaphum", 20F);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(240, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 52);
            this.label1.TabIndex = 4;
            this.label1.Text = "កម្រិតសិក្សា | Level";
            // 
            // Btn_Close
            // 
            this.Btn_Close.FlatAppearance.BorderSize = 0;
            this.Btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Close.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Close.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.Btn_Close.IconColor = System.Drawing.Color.Red;
            this.Btn_Close.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Close.IconSize = 35;
            this.Btn_Close.Location = new System.Drawing.Point(762, 3);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(35, 35);
            this.Btn_Close.TabIndex = 3;
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Frm_Level
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.panel_Content);
            this.Font = new System.Drawing.Font("Suwannaphum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Frm_Level";
            this.Text = "Frm_Level";
            this.panel_Content.ResumeLayout(false);
            this.panel_Content.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Content;
        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconButton Btn_Close;
        private FontAwesome.Sharp.IconButton ID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Txt_ID;
        private System.Windows.Forms.TextBox Txt_Description;
        private FontAwesome.Sharp.IconButton iconButton4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox Txt_NameEN;
        private FontAwesome.Sharp.IconButton name;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Txt_level;
        private FontAwesome.Sharp.IconButton level;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView DGV_Data;
        private FontAwesome.Sharp.IconButton Btn_Edit;
        private FontAwesome.Sharp.IconButton Btn_Save;
        private FontAwesome.Sharp.IconButton Btn_Delete;
    }
}