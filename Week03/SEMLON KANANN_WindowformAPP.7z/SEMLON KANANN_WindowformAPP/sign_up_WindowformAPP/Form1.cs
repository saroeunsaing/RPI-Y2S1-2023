﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sign_up_WindowformAPP
{
    public partial class FormAPP : Form
    {
        public FormAPP()
        {
            InitializeComponent();
        }

        private void panel_right_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Ruler_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_signup_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Txt_box5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_signup_MouseHover(object sender, EventArgs e)
        {

        }
    }
}
