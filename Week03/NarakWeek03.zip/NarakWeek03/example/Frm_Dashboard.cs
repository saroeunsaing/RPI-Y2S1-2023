namespace example
{
    public partial class Frm_Dashboard : Form
    {
        public Frm_Dashboard()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_Home_Click(object sender, EventArgs e)
        {

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Setting_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Left_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Btn_Instagram_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Whatapp_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Restore_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            Btn_Maximize.Visible = true;
            Btn_Restore.Visible = false;
        }

        private void Btn_Maximize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            Btn_Restore.Visible = true;
            Btn_Maximize.Visible = false;
        }

        private void Btn_Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Btn_Fecebok_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Messenger_Click(object sender, EventArgs e)
        {

        }

        private void Btn_Telegram_Click(object sender, EventArgs e)
        {
        }
    }
}