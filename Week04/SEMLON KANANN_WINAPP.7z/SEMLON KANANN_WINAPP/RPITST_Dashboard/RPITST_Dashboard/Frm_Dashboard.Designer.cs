﻿namespace RPITST_Dashboard
{
    partial class Frm_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_Title = new System.Windows.Forms.Panel();
            this.Btn_Maximize = new FontAwesome.Sharp.IconButton();
            this.Btn_Close = new FontAwesome.Sharp.IconButton();
            this.Btn_Minimize = new FontAwesome.Sharp.IconButton();
            this.Btn_Restore = new FontAwesome.Sharp.IconButton();
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.iconButton10 = new FontAwesome.Sharp.IconButton();
            this.iconButton7 = new FontAwesome.Sharp.IconButton();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.iconButton9 = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.btn_signout = new FontAwesome.Sharp.IconButton();
            this.btn_sitting = new FontAwesome.Sharp.IconButton();
            this.btn_level = new FontAwesome.Sharp.IconButton();
            this.Btn_Home = new FontAwesome.Sharp.IconButton();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.Btn_Menu = new FontAwesome.Sharp.IconButton();
            this.panel_Content = new System.Windows.Forms.Panel();
            this.Timer_Hide = new System.Windows.Forms.Timer(this.components);
            this.Timer_Show = new System.Windows.Forms.Timer(this.components);
            this.panel_Title.SuspendLayout();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Title
            // 
            this.panel_Title.BackColor = System.Drawing.Color.DarkGray;
            this.panel_Title.Controls.Add(this.Btn_Maximize);
            this.panel_Title.Controls.Add(this.Btn_Close);
            this.panel_Title.Controls.Add(this.Btn_Minimize);
            this.panel_Title.Controls.Add(this.Btn_Restore);
            this.panel_Title.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Title.Location = new System.Drawing.Point(0, 0);
            this.panel_Title.Name = "panel_Title";
            this.panel_Title.Size = new System.Drawing.Size(1100, 35);
            this.panel_Title.TabIndex = 2;
            // 
            // Btn_Maximize
            // 
            this.Btn_Maximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Maximize.FlatAppearance.BorderSize = 0;
            this.Btn_Maximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Maximize.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Maximize.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.Btn_Maximize.IconColor = System.Drawing.Color.Red;
            this.Btn_Maximize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Maximize.IconSize = 35;
            this.Btn_Maximize.Location = new System.Drawing.Point(1031, 3);
            this.Btn_Maximize.Name = "Btn_Maximize";
            this.Btn_Maximize.Size = new System.Drawing.Size(35, 31);
            this.Btn_Maximize.TabIndex = 3;
            this.Btn_Maximize.UseVisualStyleBackColor = true;
            this.Btn_Maximize.Click += new System.EventHandler(this.Btn_Maximize_Click);
            // 
            // Btn_Close
            // 
            this.Btn_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Close.FlatAppearance.BorderSize = 0;
            this.Btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Close.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Close.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            this.Btn_Close.IconColor = System.Drawing.Color.Red;
            this.Btn_Close.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Close.IconSize = 35;
            this.Btn_Close.Location = new System.Drawing.Point(1065, 2);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(35, 32);
            this.Btn_Close.TabIndex = 2;
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Btn_Minimize
            // 
            this.Btn_Minimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Minimize.FlatAppearance.BorderSize = 0;
            this.Btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Minimize.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Minimize.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            this.Btn_Minimize.IconColor = System.Drawing.Color.Red;
            this.Btn_Minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Minimize.IconSize = 30;
            this.Btn_Minimize.Location = new System.Drawing.Point(993, 8);
            this.Btn_Minimize.Name = "Btn_Minimize";
            this.Btn_Minimize.Size = new System.Drawing.Size(35, 23);
            this.Btn_Minimize.TabIndex = 1;
            this.Btn_Minimize.UseVisualStyleBackColor = true;
            this.Btn_Minimize.Click += new System.EventHandler(this.Btn_Minimize_Click);
            // 
            // Btn_Restore
            // 
            this.Btn_Restore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Restore.FlatAppearance.BorderSize = 0;
            this.Btn_Restore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Restore.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Restore.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            this.Btn_Restore.IconColor = System.Drawing.Color.Red;
            this.Btn_Restore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Restore.IconSize = 30;
            this.Btn_Restore.Location = new System.Drawing.Point(1031, 3);
            this.Btn_Restore.Name = "Btn_Restore";
            this.Btn_Restore.Size = new System.Drawing.Size(28, 29);
            this.Btn_Restore.TabIndex = 0;
            this.Btn_Restore.UseVisualStyleBackColor = true;
            this.Btn_Restore.Click += new System.EventHandler(this.Btn_Restore_Click);
            // 
            // panel_Menu
            // 
            this.panel_Menu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel_Menu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel_Menu.Controls.Add(this.iconButton10);
            this.panel_Menu.Controls.Add(this.iconButton7);
            this.panel_Menu.Controls.Add(this.iconButton8);
            this.panel_Menu.Controls.Add(this.iconButton9);
            this.panel_Menu.Controls.Add(this.iconButton6);
            this.panel_Menu.Controls.Add(this.iconButton5);
            this.panel_Menu.Controls.Add(this.iconButton4);
            this.panel_Menu.Controls.Add(this.btn_signout);
            this.panel_Menu.Controls.Add(this.btn_sitting);
            this.panel_Menu.Controls.Add(this.btn_level);
            this.panel_Menu.Controls.Add(this.Btn_Home);
            this.panel_Menu.Controls.Add(this.iconPictureBox1);
            this.panel_Menu.Controls.Add(this.Btn_Menu);
            this.panel_Menu.Location = new System.Drawing.Point(0, 35);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(300, 600);
            this.panel_Menu.TabIndex = 3;
            // 
            // iconButton10
            // 
            this.iconButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton10.FlatAppearance.BorderSize = 0;
            this.iconButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton10.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton10.ForeColor = System.Drawing.Color.Red;
            this.iconButton10.IconChar = FontAwesome.Sharp.IconChar.Instagram;
            this.iconButton10.IconColor = System.Drawing.Color.Red;
            this.iconButton10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton10.IconSize = 25;
            this.iconButton10.Location = new System.Drawing.Point(218, 563);
            this.iconButton10.Name = "iconButton10";
            this.iconButton10.Size = new System.Drawing.Size(25, 25);
            this.iconButton10.TabIndex = 16;
            this.iconButton10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton10.UseVisualStyleBackColor = true;
            // 
            // iconButton7
            // 
            this.iconButton7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton7.FlatAppearance.BorderSize = 0;
            this.iconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton7.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton7.ForeColor = System.Drawing.Color.Red;
            this.iconButton7.IconChar = FontAwesome.Sharp.IconChar.Tiktok;
            this.iconButton7.IconColor = System.Drawing.Color.Red;
            this.iconButton7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton7.IconSize = 25;
            this.iconButton7.Location = new System.Drawing.Point(186, 563);
            this.iconButton7.Name = "iconButton7";
            this.iconButton7.Size = new System.Drawing.Size(25, 25);
            this.iconButton7.TabIndex = 15;
            this.iconButton7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton7.UseVisualStyleBackColor = true;
            // 
            // iconButton8
            // 
            this.iconButton8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton8.FlatAppearance.BorderSize = 0;
            this.iconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton8.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton8.ForeColor = System.Drawing.Color.Red;
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.FacebookMessenger;
            this.iconButton8.IconColor = System.Drawing.Color.Red;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton8.IconSize = 25;
            this.iconButton8.Location = new System.Drawing.Point(151, 563);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(25, 25);
            this.iconButton8.TabIndex = 14;
            this.iconButton8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton8.UseVisualStyleBackColor = true;
            // 
            // iconButton9
            // 
            this.iconButton9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton9.FlatAppearance.BorderSize = 0;
            this.iconButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton9.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton9.ForeColor = System.Drawing.Color.Red;
            this.iconButton9.IconChar = FontAwesome.Sharp.IconChar.Whatsapp;
            this.iconButton9.IconColor = System.Drawing.Color.Red;
            this.iconButton9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton9.IconSize = 25;
            this.iconButton9.Location = new System.Drawing.Point(120, 563);
            this.iconButton9.Name = "iconButton9";
            this.iconButton9.Size = new System.Drawing.Size(25, 25);
            this.iconButton9.TabIndex = 13;
            this.iconButton9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton9.UseVisualStyleBackColor = true;
            // 
            // iconButton6
            // 
            this.iconButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton6.FlatAppearance.BorderSize = 0;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton6.ForeColor = System.Drawing.Color.Red;
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.Linkedin;
            this.iconButton6.IconColor = System.Drawing.Color.Red;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 25;
            this.iconButton6.Location = new System.Drawing.Point(87, 563);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(25, 25);
            this.iconButton6.TabIndex = 12;
            this.iconButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton6.UseVisualStyleBackColor = true;
            // 
            // iconButton5
            // 
            this.iconButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton5.FlatAppearance.BorderSize = 0;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton5.ForeColor = System.Drawing.Color.Red;
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Telegram;
            this.iconButton5.IconColor = System.Drawing.Color.Red;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 25;
            this.iconButton5.Location = new System.Drawing.Point(52, 563);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(25, 25);
            this.iconButton5.TabIndex = 11;
            this.iconButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton5.UseVisualStyleBackColor = true;
            // 
            // iconButton4
            // 
            this.iconButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iconButton4.FlatAppearance.BorderSize = 0;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.iconButton4.ForeColor = System.Drawing.Color.Red;
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.Facebook;
            this.iconButton4.IconColor = System.Drawing.Color.Red;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 25;
            this.iconButton4.Location = new System.Drawing.Point(21, 563);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(25, 25);
            this.iconButton4.TabIndex = 10;
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton4.UseVisualStyleBackColor = true;
            // 
            // btn_signout
            // 
            this.btn_signout.FlatAppearance.BorderSize = 0;
            this.btn_signout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_signout.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.btn_signout.ForeColor = System.Drawing.Color.Red;
            this.btn_signout.IconChar = FontAwesome.Sharp.IconChar.RightToBracket;
            this.btn_signout.IconColor = System.Drawing.Color.Red;
            this.btn_signout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_signout.IconSize = 25;
            this.btn_signout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_signout.Location = new System.Drawing.Point(0, 413);
            this.btn_signout.Name = "btn_signout";
            this.btn_signout.Size = new System.Drawing.Size(294, 35);
            this.btn_signout.TabIndex = 9;
            this.btn_signout.Text = "ចាកចេញ | Sign Out";
            this.btn_signout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_signout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_signout.UseVisualStyleBackColor = true;
            // 
            // btn_sitting
            // 
            this.btn_sitting.FlatAppearance.BorderSize = 0;
            this.btn_sitting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sitting.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.btn_sitting.ForeColor = System.Drawing.Color.Red;
            this.btn_sitting.IconChar = FontAwesome.Sharp.IconChar.Gear;
            this.btn_sitting.IconColor = System.Drawing.Color.Red;
            this.btn_sitting.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_sitting.IconSize = 25;
            this.btn_sitting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sitting.Location = new System.Drawing.Point(0, 372);
            this.btn_sitting.Name = "btn_sitting";
            this.btn_sitting.Size = new System.Drawing.Size(294, 35);
            this.btn_sitting.TabIndex = 8;
            this.btn_sitting.Text = "ការកំណត់ | Setting";
            this.btn_sitting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sitting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_sitting.UseVisualStyleBackColor = true;
            // 
            // btn_level
            // 
            this.btn_level.FlatAppearance.BorderSize = 0;
            this.btn_level.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_level.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.btn_level.ForeColor = System.Drawing.Color.Red;
            this.btn_level.IconChar = FontAwesome.Sharp.IconChar.UserGraduate;
            this.btn_level.IconColor = System.Drawing.Color.Red;
            this.btn_level.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_level.IconSize = 25;
            this.btn_level.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_level.Location = new System.Drawing.Point(0, 331);
            this.btn_level.Name = "btn_level";
            this.btn_level.Size = new System.Drawing.Size(294, 35);
            this.btn_level.TabIndex = 7;
            this.btn_level.Text = "ព័ត៌មាននិស្សិត | Student";
            this.btn_level.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_level.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_level.UseVisualStyleBackColor = true;
            this.btn_level.Click += new System.EventHandler(this.btn_level_Click);
            // 
            // Btn_Home
            // 
            this.Btn_Home.FlatAppearance.BorderSize = 0;
            this.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Home.Font = new System.Drawing.Font("Suwannaphum", 12F);
            this.Btn_Home.ForeColor = System.Drawing.Color.Red;
            this.Btn_Home.IconChar = FontAwesome.Sharp.IconChar.HomeLg;
            this.Btn_Home.IconColor = System.Drawing.Color.Red;
            this.Btn_Home.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Home.IconSize = 25;
            this.Btn_Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Home.Location = new System.Drawing.Point(0, 290);
            this.Btn_Home.Name = "Btn_Home";
            this.Btn_Home.Size = new System.Drawing.Size(294, 35);
            this.Btn_Home.TabIndex = 6;
            this.Btn_Home.Text = "ទំព័រដើម | Home";
            this.Btn_Home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Home.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Home.UseVisualStyleBackColor = true;
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.iconPictureBox1.ForeColor = System.Drawing.Color.IndianRed;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserAlt;
            this.iconPictureBox1.IconColor = System.Drawing.Color.IndianRed;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 150;
            this.iconPictureBox1.Location = new System.Drawing.Point(59, 74);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(150, 150);
            this.iconPictureBox1.TabIndex = 5;
            this.iconPictureBox1.TabStop = false;
            // 
            // Btn_Menu
            // 
            this.Btn_Menu.FlatAppearance.BorderSize = 0;
            this.Btn_Menu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Menu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_Menu.IconChar = FontAwesome.Sharp.IconChar.List;
            this.Btn_Menu.IconColor = System.Drawing.Color.Red;
            this.Btn_Menu.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Menu.IconSize = 35;
            this.Btn_Menu.Location = new System.Drawing.Point(259, 6);
            this.Btn_Menu.Name = "Btn_Menu";
            this.Btn_Menu.Size = new System.Drawing.Size(35, 35);
            this.Btn_Menu.TabIndex = 4;
            this.Btn_Menu.UseVisualStyleBackColor = true;
            this.Btn_Menu.Click += new System.EventHandler(this.Btn_Menu_Click);
            // 
            // panel_Content
            // 
            this.panel_Content.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_Content.BackColor = System.Drawing.Color.Chartreuse;
            this.panel_Content.Location = new System.Drawing.Point(300, 35);
            this.panel_Content.Name = "panel_Content";
            this.panel_Content.Size = new System.Drawing.Size(800, 600);
            this.panel_Content.TabIndex = 4;
            // 
            // Frm_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1100, 635);
            this.Controls.Add(this.panel_Content);
            this.Controls.Add(this.panel_Menu);
            this.Controls.Add(this.panel_Title);
            this.Font = new System.Drawing.Font("Suwannaphum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Frm_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Frm_Dashboard_Load);
            this.panel_Title.ResumeLayout(false);
            this.panel_Menu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel_Title;
        private System.Windows.Forms.Panel panel_Menu;
        private FontAwesome.Sharp.IconButton Btn_Maximize;
        private FontAwesome.Sharp.IconButton Btn_Close;
        private FontAwesome.Sharp.IconButton Btn_Minimize;
        private FontAwesome.Sharp.IconButton Btn_Restore;
        private System.Windows.Forms.Panel panel_Content;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private FontAwesome.Sharp.IconButton Btn_Menu;
        private FontAwesome.Sharp.IconButton Btn_Home;
        private FontAwesome.Sharp.IconButton iconButton6;
        private FontAwesome.Sharp.IconButton iconButton5;
        private FontAwesome.Sharp.IconButton iconButton4;
        private FontAwesome.Sharp.IconButton btn_signout;
        private FontAwesome.Sharp.IconButton btn_sitting;
        private FontAwesome.Sharp.IconButton btn_level;
        private FontAwesome.Sharp.IconButton iconButton10;
        private FontAwesome.Sharp.IconButton iconButton7;
        private FontAwesome.Sharp.IconButton iconButton8;
        private FontAwesome.Sharp.IconButton iconButton9;
        private System.Windows.Forms.Timer Timer_Hide;
        private System.Windows.Forms.Timer Timer_Show;
    }
}

