﻿namespace example
{
    partial class Frm_Dashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            fontDialog1 = new FontDialog();
            Btn_Top = new Panel();
            Btn_Minimize = new FontAwesome.Sharp.IconButton();
            Btn_Maximize = new FontAwesome.Sharp.IconButton();
            Btn_Restore = new FontAwesome.Sharp.IconButton();
            Btn_Close = new FontAwesome.Sharp.IconButton();
            Btn_Left = new Panel();
            Btn_User = new FontAwesome.Sharp.IconButton();
            Btn_Whatapp = new FontAwesome.Sharp.IconButton();
            Btn_Telegram = new FontAwesome.Sharp.IconButton();
            Btn_Instagram = new FontAwesome.Sharp.IconButton();
            Btn_Messenger = new FontAwesome.Sharp.IconButton();
            Btn_Fecebok = new FontAwesome.Sharp.IconButton();
            Btn_Signout = new FontAwesome.Sharp.IconButton();
            Btn_Setting = new FontAwesome.Sharp.IconButton();
            Btn_Student = new FontAwesome.Sharp.IconButton();
            Btn_Home = new FontAwesome.Sharp.IconButton();
            Btn_List = new FontAwesome.Sharp.IconButton();
            Btn_Top.SuspendLayout();
            Btn_Left.SuspendLayout();
            SuspendLayout();
            // 
            // Btn_Top
            // 
            Btn_Top.BackColor = Color.DarkGray;
            Btn_Top.Controls.Add(Btn_Minimize);
            Btn_Top.Controls.Add(Btn_Maximize);
            Btn_Top.Controls.Add(Btn_Restore);
            Btn_Top.Controls.Add(Btn_Close);
            Btn_Top.Dock = DockStyle.Top;
            Btn_Top.Location = new Point(0, 0);
            Btn_Top.Name = "Btn_Top";
            Btn_Top.Size = new Size(1100, 35);
            Btn_Top.TabIndex = 0;
            // 
            // Btn_Minimize
            // 
            Btn_Minimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            Btn_Minimize.BackColor = Color.DarkGray;
            Btn_Minimize.FlatAppearance.BorderSize = 0;
            Btn_Minimize.FlatStyle = FlatStyle.Flat;
            Btn_Minimize.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            Btn_Minimize.IconColor = Color.Red;
            Btn_Minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Minimize.IconSize = 30;
            Btn_Minimize.Location = new Point(986, 1);
            Btn_Minimize.Name = "Btn_Minimize";
            Btn_Minimize.Size = new Size(36, 33);
            Btn_Minimize.TabIndex = 4;
            Btn_Minimize.UseVisualStyleBackColor = false;
            Btn_Minimize.Click += Btn_Minimize_Click;
            // 
            // Btn_Maximize
            // 
            Btn_Maximize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            Btn_Maximize.BackColor = Color.DarkGray;
            Btn_Maximize.FlatAppearance.BorderSize = 0;
            Btn_Maximize.FlatStyle = FlatStyle.Flat;
            Btn_Maximize.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            Btn_Maximize.IconColor = Color.Red;
            Btn_Maximize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Maximize.IconSize = 30;
            Btn_Maximize.Location = new Point(1022, 1);
            Btn_Maximize.Name = "Btn_Maximize";
            Btn_Maximize.Size = new Size(37, 32);
            Btn_Maximize.TabIndex = 3;
            Btn_Maximize.UseVisualStyleBackColor = false;
            Btn_Maximize.Click += Btn_Maximize_Click;
            // 
            // Btn_Restore
            // 
            Btn_Restore.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            Btn_Restore.FlatAppearance.BorderSize = 0;
            Btn_Restore.FlatStyle = FlatStyle.Flat;
            Btn_Restore.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            Btn_Restore.IconColor = Color.Red;
            Btn_Restore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Restore.IconSize = 30;
            Btn_Restore.Location = new Point(1022, 1);
            Btn_Restore.Name = "Btn_Restore";
            Btn_Restore.Size = new Size(37, 33);
            Btn_Restore.TabIndex = 2;
            Btn_Restore.UseVisualStyleBackColor = true;
            Btn_Restore.Click += Btn_Restore_Click;
            // 
            // Btn_Close
            // 
            Btn_Close.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            Btn_Close.FlatAppearance.BorderSize = 0;
            Btn_Close.FlatStyle = FlatStyle.Flat;
            Btn_Close.IconChar = FontAwesome.Sharp.IconChar.Xmark;
            Btn_Close.IconColor = Color.Red;
            Btn_Close.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Close.IconSize = 30;
            Btn_Close.Location = new Point(1060, 1);
            Btn_Close.Name = "Btn_Close";
            Btn_Close.Size = new Size(36, 32);
            Btn_Close.TabIndex = 2;
            Btn_Close.UseVisualStyleBackColor = true;
            Btn_Close.Click += Btn_Close_Click;
            // 
            // Btn_Left
            // 
            Btn_Left.BackColor = Color.LightSkyBlue;
            Btn_Left.Controls.Add(Btn_User);
            Btn_Left.Controls.Add(Btn_Whatapp);
            Btn_Left.Controls.Add(Btn_Telegram);
            Btn_Left.Controls.Add(Btn_Instagram);
            Btn_Left.Controls.Add(Btn_Messenger);
            Btn_Left.Controls.Add(Btn_Fecebok);
            Btn_Left.Controls.Add(Btn_Signout);
            Btn_Left.Controls.Add(Btn_Setting);
            Btn_Left.Controls.Add(Btn_Student);
            Btn_Left.Controls.Add(Btn_Home);
            Btn_Left.Controls.Add(Btn_List);
            Btn_Left.Dock = DockStyle.Left;
            Btn_Left.Location = new Point(0, 35);
            Btn_Left.Name = "Btn_Left";
            Btn_Left.Size = new Size(325, 600);
            Btn_Left.TabIndex = 1;
            Btn_Left.Paint += Btn_Left_Paint;
            // 
            // Btn_User
            // 
            Btn_User.FlatAppearance.BorderSize = 0;
            Btn_User.FlatStyle = FlatStyle.Flat;
            Btn_User.IconChar = FontAwesome.Sharp.IconChar.UserAlt;
            Btn_User.IconColor = Color.IndianRed;
            Btn_User.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_User.IconSize = 90;
            Btn_User.Location = new Point(72, 66);
            Btn_User.Name = "Btn_User";
            Btn_User.Size = new Size(144, 119);
            Btn_User.TabIndex = 11;
            Btn_User.UseVisualStyleBackColor = true;
            // 
            // Btn_Whatapp
            // 
            Btn_Whatapp.Anchor = AnchorStyles.Bottom;
            Btn_Whatapp.FlatAppearance.BorderSize = 0;
            Btn_Whatapp.FlatStyle = FlatStyle.Flat;
            Btn_Whatapp.IconChar = FontAwesome.Sharp.IconChar.Whatsapp;
            Btn_Whatapp.IconColor = Color.Green;
            Btn_Whatapp.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Whatapp.IconSize = 30;
            Btn_Whatapp.Location = new Point(209, 551);
            Btn_Whatapp.Name = "Btn_Whatapp";
            Btn_Whatapp.Size = new Size(40, 40);
            Btn_Whatapp.TabIndex = 10;
            Btn_Whatapp.UseVisualStyleBackColor = true;
            Btn_Whatapp.Click += Btn_Whatapp_Click;
            // 
            // Btn_Telegram
            // 
            Btn_Telegram.Anchor = AnchorStyles.Bottom;
            Btn_Telegram.FlatAppearance.BorderSize = 0;
            Btn_Telegram.FlatStyle = FlatStyle.Flat;
            Btn_Telegram.IconChar = FontAwesome.Sharp.IconChar.Telegram;
            Btn_Telegram.IconColor = Color.Blue;
            Btn_Telegram.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Telegram.IconSize = 30;
            Btn_Telegram.Location = new Point(166, 551);
            Btn_Telegram.Name = "Btn_Telegram";
            Btn_Telegram.Size = new Size(40, 40);
            Btn_Telegram.TabIndex = 9;
            Btn_Telegram.UseVisualStyleBackColor = true;
            Btn_Telegram.Click += Btn_Telegram_Click;
            // 
            // Btn_Instagram
            // 
            Btn_Instagram.Anchor = AnchorStyles.Bottom;
            Btn_Instagram.FlatAppearance.BorderSize = 0;
            Btn_Instagram.FlatStyle = FlatStyle.Flat;
            Btn_Instagram.IconChar = FontAwesome.Sharp.IconChar.InstagramSquare;
            Btn_Instagram.IconColor = Color.Red;
            Btn_Instagram.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Instagram.IconSize = 30;
            Btn_Instagram.Location = new Point(126, 551);
            Btn_Instagram.Name = "Btn_Instagram";
            Btn_Instagram.Size = new Size(40, 40);
            Btn_Instagram.TabIndex = 8;
            Btn_Instagram.UseVisualStyleBackColor = true;
            Btn_Instagram.Click += Btn_Instagram_Click;
            // 
            // Btn_Messenger
            // 
            Btn_Messenger.Anchor = AnchorStyles.Bottom;
            Btn_Messenger.FlatAppearance.BorderSize = 0;
            Btn_Messenger.FlatStyle = FlatStyle.Flat;
            Btn_Messenger.IconChar = FontAwesome.Sharp.IconChar.FacebookMessenger;
            Btn_Messenger.IconColor = Color.FromArgb(128, 64, 64);
            Btn_Messenger.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Messenger.IconSize = 30;
            Btn_Messenger.Location = new Point(85, 551);
            Btn_Messenger.Name = "Btn_Messenger";
            Btn_Messenger.Size = new Size(40, 40);
            Btn_Messenger.TabIndex = 7;
            Btn_Messenger.UseVisualStyleBackColor = true;
            Btn_Messenger.Click += Btn_Messenger_Click;
            // 
            // Btn_Fecebok
            // 
            Btn_Fecebok.Anchor = AnchorStyles.Bottom;
            Btn_Fecebok.FlatAppearance.BorderSize = 0;
            Btn_Fecebok.FlatStyle = FlatStyle.Flat;
            Btn_Fecebok.IconChar = FontAwesome.Sharp.IconChar.Facebook;
            Btn_Fecebok.IconColor = Color.Blue;
            Btn_Fecebok.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Fecebok.IconSize = 30;
            Btn_Fecebok.Location = new Point(45, 551);
            Btn_Fecebok.Name = "Btn_Fecebok";
            Btn_Fecebok.Size = new Size(40, 40);
            Btn_Fecebok.TabIndex = 6;
            Btn_Fecebok.UseVisualStyleBackColor = true;
            Btn_Fecebok.Click += Btn_Fecebok_Click;
            // 
            // Btn_Signout
            // 
            Btn_Signout.FlatAppearance.BorderSize = 0;
            Btn_Signout.FlatStyle = FlatStyle.Flat;
            Btn_Signout.IconChar = FontAwesome.Sharp.IconChar.RightToBracket;
            Btn_Signout.IconColor = Color.Red;
            Btn_Signout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Signout.IconSize = 30;
            Btn_Signout.Location = new Point(12, 358);
            Btn_Signout.Name = "Btn_Signout";
            Btn_Signout.Size = new Size(225, 40);
            Btn_Signout.TabIndex = 5;
            Btn_Signout.Text = "ចាកចេញ | Sign Out ";
            Btn_Signout.TextImageRelation = TextImageRelation.ImageBeforeText;
            Btn_Signout.UseVisualStyleBackColor = true;
            Btn_Signout.Click += iconButton2_Click;
            // 
            // Btn_Setting
            // 
            Btn_Setting.FlatAppearance.BorderSize = 0;
            Btn_Setting.FlatStyle = FlatStyle.Flat;
            Btn_Setting.IconChar = FontAwesome.Sharp.IconChar.Gear;
            Btn_Setting.IconColor = Color.Red;
            Btn_Setting.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Setting.IconSize = 30;
            Btn_Setting.Location = new Point(12, 320);
            Btn_Setting.Name = "Btn_Setting";
            Btn_Setting.Size = new Size(225, 40);
            Btn_Setting.TabIndex = 3;
            Btn_Setting.Text = "ការកំណត់ | Setting";
            Btn_Setting.TextImageRelation = TextImageRelation.ImageBeforeText;
            Btn_Setting.UseVisualStyleBackColor = true;
            Btn_Setting.Click += Btn_Setting_Click;
            // 
            // Btn_Student
            // 
            Btn_Student.FlatAppearance.BorderSize = 0;
            Btn_Student.FlatStyle = FlatStyle.Flat;
            Btn_Student.IconChar = FontAwesome.Sharp.IconChar.UserGraduate;
            Btn_Student.IconColor = Color.Red;
            Btn_Student.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Student.IconSize = 30;
            Btn_Student.Location = new Point(12, 281);
            Btn_Student.Name = "Btn_Student";
            Btn_Student.Size = new Size(256, 40);
            Btn_Student.TabIndex = 2;
            Btn_Student.Text = "ពត៌មាននិស្សិត | Student";
            Btn_Student.TextImageRelation = TextImageRelation.ImageBeforeText;
            Btn_Student.UseVisualStyleBackColor = true;
            // 
            // Btn_Home
            // 
            Btn_Home.FlatAppearance.BorderSize = 0;
            Btn_Home.FlatStyle = FlatStyle.Flat;
            Btn_Home.IconChar = FontAwesome.Sharp.IconChar.HomeLg;
            Btn_Home.IconColor = Color.Red;
            Btn_Home.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_Home.IconSize = 30;
            Btn_Home.Location = new Point(12, 243);
            Btn_Home.Name = "Btn_Home";
            Btn_Home.Size = new Size(204, 40);
            Btn_Home.TabIndex = 1;
            Btn_Home.Text = "ទំព័រដើម | HOME";
            Btn_Home.TextImageRelation = TextImageRelation.ImageBeforeText;
            Btn_Home.UseVisualStyleBackColor = true;
            Btn_Home.Click += Btn_Home_Click;
            // 
            // Btn_List
            // 
            Btn_List.FlatAppearance.BorderSize = 0;
            Btn_List.FlatStyle = FlatStyle.Flat;
            Btn_List.IconChar = FontAwesome.Sharp.IconChar.List;
            Btn_List.IconColor = Color.Black;
            Btn_List.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Btn_List.IconSize = 35;
            Btn_List.Location = new Point(282, 3);
            Btn_List.Name = "Btn_List";
            Btn_List.Size = new Size(40, 40);
            Btn_List.TabIndex = 0;
            Btn_List.UseVisualStyleBackColor = true;
            // 
            // Frm_Dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Salmon;
            ClientSize = new Size(1100, 635);
            Controls.Add(Btn_Left);
            Controls.Add(Btn_Top);
            Font = new Font("Suwannaphum", 12F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "Frm_Dashboard";
            Text = "Form1";
            Load += Form1_Load;
            Btn_Top.ResumeLayout(false);
            Btn_Left.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private FontDialog fontDialog1;
        private Panel Btn_Top;
        private Panel Btn_Left;
        private FontAwesome.Sharp.IconButton Btn_Close;
        private FontAwesome.Sharp.IconButton Btn_Restore;
        private FontAwesome.Sharp.IconButton Btn_Maximize;
        private FontAwesome.Sharp.IconButton Btn_Minimize;
        private FontAwesome.Sharp.IconButton Btn_List;
        private FontAwesome.Sharp.IconButton Btn_Home;
        private FontAwesome.Sharp.IconButton Btn_Student;
        private FontAwesome.Sharp.IconButton Btn_Setting;
        private FontAwesome.Sharp.IconButton Btn_Signout;
        private FontAwesome.Sharp.IconButton Btn_Messenger;
        private FontAwesome.Sharp.IconButton Btn_Fecebok;
        private FontAwesome.Sharp.IconButton Btn_Instagram;
        private FontAwesome.Sharp.IconButton Btn_Telegram;
        private FontAwesome.Sharp.IconButton Btn_Whatapp;
        private FontAwesome.Sharp.IconButton Btn_User;
    }
}