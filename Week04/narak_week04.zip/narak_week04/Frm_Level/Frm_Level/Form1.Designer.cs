﻿namespace Frm_Level
{
    partial class Frm_level
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Close = new FontAwesome.Sharp.IconButton();
            this.Btn_Title = new System.Windows.Forms.Label();
            this.Btn_ID = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Txt_ID = new System.Windows.Forms.TextBox();
            this.Btn_Name = new FontAwesome.Sharp.IconButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Txt_Namekh = new System.Windows.Forms.TextBox();
            this.Btn_Nameeg = new FontAwesome.Sharp.IconButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Txt_Nameeg = new System.Windows.Forms.TextBox();
            this.Btn_Descript = new FontAwesome.Sharp.IconButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Txt_Descript = new System.Windows.Forms.TextBox();
            this.Btn_Save = new FontAwesome.Sharp.IconButton();
            this.Btn_Edit = new FontAwesome.Sharp.IconButton();
            this.Btn_Delete = new FontAwesome.Sharp.IconButton();
            this.DGV_Data = new System.Windows.Forms.DataGridView();
            this.Btn_Minimize = new FontAwesome.Sharp.IconButton();
            this.Btn_Maximize = new FontAwesome.Sharp.IconButton();
            this.Btn_Restore = new FontAwesome.Sharp.IconButton();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_Close
            // 
            this.Btn_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Close.FlatAppearance.BorderSize = 0;
            this.Btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Close.IconChar = FontAwesome.Sharp.IconChar.Multiply;
            this.Btn_Close.IconColor = System.Drawing.Color.Red;
            this.Btn_Close.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Close.IconSize = 40;
            this.Btn_Close.Location = new System.Drawing.Point(766, 1);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(35, 35);
            this.Btn_Close.TabIndex = 0;
            this.Btn_Close.UseVisualStyleBackColor = true;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Btn_Title
            // 
            this.Btn_Title.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Btn_Title.AutoSize = true;
            this.Btn_Title.Font = new System.Drawing.Font("Suwannaphum", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Title.ForeColor = System.Drawing.Color.Blue;
            this.Btn_Title.Location = new System.Drawing.Point(267, 24);
            this.Btn_Title.Name = "Btn_Title";
            this.Btn_Title.Size = new System.Drawing.Size(203, 37);
            this.Btn_Title.TabIndex = 1;
            this.Btn_Title.Text = "កម្រិតសិក្សា | Level";
            this.Btn_Title.Click += new System.EventHandler(this.label1_Click);
            // 
            // Btn_ID
            // 
            this.Btn_ID.FlatAppearance.BorderSize = 0;
            this.Btn_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_ID.IconChar = FontAwesome.Sharp.IconChar.IdBadge;
            this.Btn_ID.IconColor = System.Drawing.Color.Red;
            this.Btn_ID.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_ID.IconSize = 30;
            this.Btn_ID.Location = new System.Drawing.Point(42, 103);
            this.Btn_ID.Name = "Btn_ID";
            this.Btn_ID.Size = new System.Drawing.Size(35, 35);
            this.Btn_ID.TabIndex = 2;
            this.Btn_ID.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(42, 140);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 3);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // Txt_ID
            // 
            this.Txt_ID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_ID.BackColor = System.Drawing.Color.LightBlue;
            this.Txt_ID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_ID.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Txt_ID.Location = new System.Drawing.Point(81, 107);
            this.Txt_ID.Name = "Txt_ID";
            this.Txt_ID.Size = new System.Drawing.Size(411, 29);
            this.Txt_ID.TabIndex = 4;
            this.Txt_ID.Text = "លេខសម្គាល់";
            // 
            // Btn_Name
            // 
            this.Btn_Name.FlatAppearance.BorderSize = 0;
            this.Btn_Name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Name.IconChar = FontAwesome.Sharp.IconChar.Keyboard;
            this.Btn_Name.IconColor = System.Drawing.Color.Red;
            this.Btn_Name.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Name.IconSize = 30;
            this.Btn_Name.Location = new System.Drawing.Point(42, 146);
            this.Btn_Name.Name = "Btn_Name";
            this.Btn_Name.Size = new System.Drawing.Size(35, 35);
            this.Btn_Name.TabIndex = 2;
            this.Btn_Name.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(42, 183);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(451, 3);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint_1);
            // 
            // Txt_Namekh
            // 
            this.Txt_Namekh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Namekh.BackColor = System.Drawing.Color.LightBlue;
            this.Txt_Namekh.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_Namekh.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Txt_Namekh.Location = new System.Drawing.Point(81, 150);
            this.Txt_Namekh.Name = "Txt_Namekh";
            this.Txt_Namekh.Size = new System.Drawing.Size(411, 29);
            this.Txt_Namekh.TabIndex = 4;
            this.Txt_Namekh.Text = "កម្រិតសិក្សា";
            // 
            // Btn_Nameeg
            // 
            this.Btn_Nameeg.FlatAppearance.BorderSize = 0;
            this.Btn_Nameeg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Nameeg.IconChar = FontAwesome.Sharp.IconChar.A;
            this.Btn_Nameeg.IconColor = System.Drawing.Color.Red;
            this.Btn_Nameeg.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Nameeg.IconSize = 30;
            this.Btn_Nameeg.Location = new System.Drawing.Point(42, 189);
            this.Btn_Nameeg.Name = "Btn_Nameeg";
            this.Btn_Nameeg.Size = new System.Drawing.Size(35, 35);
            this.Btn_Nameeg.TabIndex = 2;
            this.Btn_Nameeg.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Location = new System.Drawing.Point(42, 226);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(451, 3);
            this.panel3.TabIndex = 3;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Txt_Nameeg
            // 
            this.Txt_Nameeg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Nameeg.BackColor = System.Drawing.Color.LightBlue;
            this.Txt_Nameeg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_Nameeg.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Txt_Nameeg.Location = new System.Drawing.Point(81, 193);
            this.Txt_Nameeg.Name = "Txt_Nameeg";
            this.Txt_Nameeg.Size = new System.Drawing.Size(411, 29);
            this.Txt_Nameeg.TabIndex = 4;
            this.Txt_Nameeg.Text = "ជាឡាតាំង";
            // 
            // Btn_Descript
            // 
            this.Btn_Descript.FlatAppearance.BorderSize = 0;
            this.Btn_Descript.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Descript.IconChar = FontAwesome.Sharp.IconChar.ListDots;
            this.Btn_Descript.IconColor = System.Drawing.Color.Red;
            this.Btn_Descript.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Descript.IconSize = 30;
            this.Btn_Descript.Location = new System.Drawing.Point(42, 232);
            this.Btn_Descript.Name = "Btn_Descript";
            this.Btn_Descript.Size = new System.Drawing.Size(35, 35);
            this.Btn_Descript.TabIndex = 2;
            this.Btn_Descript.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.Red;
            this.panel4.Location = new System.Drawing.Point(42, 269);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(451, 3);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // Txt_Descript
            // 
            this.Txt_Descript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Descript.BackColor = System.Drawing.Color.LightBlue;
            this.Txt_Descript.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_Descript.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Txt_Descript.Location = new System.Drawing.Point(81, 236);
            this.Txt_Descript.Name = "Txt_Descript";
            this.Txt_Descript.Size = new System.Drawing.Size(411, 29);
            this.Txt_Descript.TabIndex = 4;
            this.Txt_Descript.Text = "ព័ណ៌នា";
            // 
            // Btn_Save
            // 
            this.Btn_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Save.FlatAppearance.BorderSize = 0;
            this.Btn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Save.IconChar = FontAwesome.Sharp.IconChar.FloppyDisk;
            this.Btn_Save.IconColor = System.Drawing.Color.Red;
            this.Btn_Save.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Save.IconSize = 35;
            this.Btn_Save.Location = new System.Drawing.Point(563, 152);
            this.Btn_Save.Name = "Btn_Save";
            this.Btn_Save.Size = new System.Drawing.Size(190, 40);
            this.Btn_Save.TabIndex = 2;
            this.Btn_Save.Text = "រក្សាទុក | Save";
            this.Btn_Save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Save.UseVisualStyleBackColor = true;
            // 
            // Btn_Edit
            // 
            this.Btn_Edit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Edit.FlatAppearance.BorderSize = 0;
            this.Btn_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Edit.IconChar = FontAwesome.Sharp.IconChar.PencilAlt;
            this.Btn_Edit.IconColor = System.Drawing.Color.Red;
            this.Btn_Edit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Edit.IconSize = 35;
            this.Btn_Edit.Location = new System.Drawing.Point(563, 194);
            this.Btn_Edit.Name = "Btn_Edit";
            this.Btn_Edit.Size = new System.Drawing.Size(190, 40);
            this.Btn_Edit.TabIndex = 2;
            this.Btn_Edit.Text = "កែប្រែ | Edit";
            this.Btn_Edit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Edit.UseVisualStyleBackColor = true;
            // 
            // Btn_Delete
            // 
            this.Btn_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Delete.FlatAppearance.BorderSize = 0;
            this.Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Delete.IconChar = FontAwesome.Sharp.IconChar.TrashAlt;
            this.Btn_Delete.IconColor = System.Drawing.Color.Red;
            this.Btn_Delete.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Delete.IconSize = 35;
            this.Btn_Delete.Location = new System.Drawing.Point(563, 240);
            this.Btn_Delete.Name = "Btn_Delete";
            this.Btn_Delete.Size = new System.Drawing.Size(190, 40);
            this.Btn_Delete.TabIndex = 2;
            this.Btn_Delete.Text = "លុប | Delete";
            this.Btn_Delete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Delete.UseVisualStyleBackColor = true;
            // 
            // DGV_Data
            // 
            this.DGV_Data.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DGV_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Data.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DGV_Data.Location = new System.Drawing.Point(0, 310);
            this.DGV_Data.Name = "DGV_Data";
            this.DGV_Data.Size = new System.Drawing.Size(800, 290);
            this.DGV_Data.TabIndex = 5;
            // 
            // Btn_Minimize
            // 
            this.Btn_Minimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Minimize.FlatAppearance.BorderSize = 0;
            this.Btn_Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Minimize.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            this.Btn_Minimize.IconColor = System.Drawing.Color.Red;
            this.Btn_Minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Minimize.IconSize = 40;
            this.Btn_Minimize.Location = new System.Drawing.Point(684, 1);
            this.Btn_Minimize.Name = "Btn_Minimize";
            this.Btn_Minimize.Size = new System.Drawing.Size(35, 35);
            this.Btn_Minimize.TabIndex = 6;
            this.Btn_Minimize.UseVisualStyleBackColor = true;
            this.Btn_Minimize.Click += new System.EventHandler(this.Btn_Minimize_Click);
            // 
            // Btn_Maximize
            // 
            this.Btn_Maximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Maximize.FlatAppearance.BorderSize = 0;
            this.Btn_Maximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Maximize.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.Btn_Maximize.IconColor = System.Drawing.Color.Red;
            this.Btn_Maximize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Maximize.IconSize = 40;
            this.Btn_Maximize.Location = new System.Drawing.Point(725, 1);
            this.Btn_Maximize.Name = "Btn_Maximize";
            this.Btn_Maximize.Size = new System.Drawing.Size(35, 35);
            this.Btn_Maximize.TabIndex = 7;
            this.Btn_Maximize.UseVisualStyleBackColor = true;
            this.Btn_Maximize.Click += new System.EventHandler(this.Btn_Maximize_Click);
            // 
            // Btn_Restore
            // 
            this.Btn_Restore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Restore.FlatAppearance.BorderSize = 0;
            this.Btn_Restore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Restore.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            this.Btn_Restore.IconColor = System.Drawing.Color.Red;
            this.Btn_Restore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_Restore.IconSize = 40;
            this.Btn_Restore.Location = new System.Drawing.Point(725, 1);
            this.Btn_Restore.Name = "Btn_Restore";
            this.Btn_Restore.Size = new System.Drawing.Size(35, 35);
            this.Btn_Restore.TabIndex = 8;
            this.Btn_Restore.UseVisualStyleBackColor = true;
            this.Btn_Restore.Click += new System.EventHandler(this.Btn_Restore_Click);
            // 
            // Frm_level
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.Btn_Restore);
            this.Controls.Add(this.Btn_Maximize);
            this.Controls.Add(this.Btn_Minimize);
            this.Controls.Add(this.DGV_Data);
            this.Controls.Add(this.Txt_Descript);
            this.Controls.Add(this.Txt_Nameeg);
            this.Controls.Add(this.Txt_Namekh);
            this.Controls.Add(this.Txt_ID);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Btn_Descript);
            this.Controls.Add(this.Btn_Nameeg);
            this.Controls.Add(this.Btn_Name);
            this.Controls.Add(this.Btn_Delete);
            this.Controls.Add(this.Btn_Edit);
            this.Controls.Add(this.Btn_Save);
            this.Controls.Add(this.Btn_ID);
            this.Controls.Add(this.Btn_Title);
            this.Controls.Add(this.Btn_Close);
            this.Font = new System.Drawing.Font("Suwannaphum", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Frm_level";
            this.Load += new System.EventHandler(this.Frm_level_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FontAwesome.Sharp.IconButton Btn_Close;
        private System.Windows.Forms.Label Btn_Title;
        private FontAwesome.Sharp.IconButton Btn_ID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Txt_ID;
        private FontAwesome.Sharp.IconButton Btn_Name;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Txt_Namekh;
        private FontAwesome.Sharp.IconButton Btn_Nameeg;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Txt_Nameeg;
        private FontAwesome.Sharp.IconButton Btn_Descript;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox Txt_Descript;
        private FontAwesome.Sharp.IconButton Btn_Save;
        private FontAwesome.Sharp.IconButton Btn_Edit;
        private FontAwesome.Sharp.IconButton Btn_Delete;
        private System.Windows.Forms.DataGridView DGV_Data;
        private FontAwesome.Sharp.IconButton Btn_Minimize;
        private FontAwesome.Sharp.IconButton Btn_Maximize;
        private FontAwesome.Sharp.IconButton Btn_Restore;
    }
}

