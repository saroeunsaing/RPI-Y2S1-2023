﻿namespace sign_up_WindowformAPP
{
    partial class FormAPP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_left = new System.Windows.Forms.Panel();
            this.panel_right = new System.Windows.Forms.Panel();
            this.signUp = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.Ruler = new System.Windows.Forms.Panel();
            this.Password = new System.Windows.Forms.Label();
            this.Ruler1 = new System.Windows.Forms.Panel();
            this.Ruler2 = new System.Windows.Forms.Panel();
            this.Re_Enter_Password = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Ruler3 = new System.Windows.Forms.Panel();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_signup = new System.Windows.Forms.Button();
            this.checkBox = new System.Windows.Forms.CheckBox();
            this.Txt_box = new System.Windows.Forms.TextBox();
            this.Txt_box1 = new System.Windows.Forms.TextBox();
            this.Txt_box2 = new System.Windows.Forms.TextBox();
            this.Txt_box3 = new System.Windows.Forms.TextBox();
            this.Txt_box5 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Txt_box4 = new System.Windows.Forms.TextBox();
            this.panel_left.SuspendLayout();
            this.panel_right.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_left
            // 
            this.panel_left.BackColor = System.Drawing.Color.Red;
            this.panel_left.Controls.Add(this.Txt_box4);
            this.panel_left.Controls.Add(this.pictureBox1);
            this.panel_left.Controls.Add(this.Txt_box5);
            this.panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_left.ForeColor = System.Drawing.Color.White;
            this.panel_left.Location = new System.Drawing.Point(0, 0);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(400, 500);
            this.panel_left.TabIndex = 0;
            // 
            // panel_right
            // 
            this.panel_right.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_right.Controls.Add(this.Txt_box3);
            this.panel_right.Controls.Add(this.Txt_box2);
            this.panel_right.Controls.Add(this.Txt_box1);
            this.panel_right.Controls.Add(this.Txt_box);
            this.panel_right.Controls.Add(this.checkBox);
            this.panel_right.Controls.Add(this.btn_signup);
            this.panel_right.Controls.Add(this.btn_clear);
            this.panel_right.Controls.Add(this.Ruler3);
            this.panel_right.Controls.Add(this.Email);
            this.panel_right.Controls.Add(this.Re_Enter_Password);
            this.panel_right.Controls.Add(this.Ruler2);
            this.panel_right.Controls.Add(this.Ruler1);
            this.panel_right.Controls.Add(this.Password);
            this.panel_right.Controls.Add(this.Ruler);
            this.panel_right.Controls.Add(this.UserName);
            this.panel_right.Controls.Add(this.signUp);
            this.panel_right.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_right.Location = new System.Drawing.Point(400, 0);
            this.panel_right.Name = "panel_right";
            this.panel_right.Size = new System.Drawing.Size(400, 500);
            this.panel_right.TabIndex = 1;
            this.panel_right.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_right_Paint);
            // 
            // signUp
            // 
            this.signUp.AutoSize = true;
            this.signUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.signUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.signUp.ForeColor = System.Drawing.Color.Crimson;
            this.signUp.Location = new System.Drawing.Point(144, 59);
            this.signUp.Name = "signUp";
            this.signUp.Size = new System.Drawing.Size(105, 31);
            this.signUp.TabIndex = 0;
            this.signUp.Text = "Sign up";
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.UserName.ForeColor = System.Drawing.Color.Red;
            this.UserName.Location = new System.Drawing.Point(48, 112);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(96, 20);
            this.UserName.TabIndex = 1;
            this.UserName.Text = "User name:";
            // 
            // Ruler
            // 
            this.Ruler.BackColor = System.Drawing.Color.Red;
            this.Ruler.Location = new System.Drawing.Point(52, 157);
            this.Ruler.Name = "Ruler";
            this.Ruler.Size = new System.Drawing.Size(280, 3);
            this.Ruler.TabIndex = 2;
            this.Ruler.Paint += new System.Windows.Forms.PaintEventHandler(this.Ruler_Paint);
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Password.ForeColor = System.Drawing.Color.Red;
            this.Password.Location = new System.Drawing.Point(47, 175);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(88, 20);
            this.Password.TabIndex = 3;
            this.Password.Text = "Password:";
            // 
            // Ruler1
            // 
            this.Ruler1.BackColor = System.Drawing.Color.Red;
            this.Ruler1.Location = new System.Drawing.Point(51, 220);
            this.Ruler1.Name = "Ruler1";
            this.Ruler1.Size = new System.Drawing.Size(280, 3);
            this.Ruler1.TabIndex = 4;
            // 
            // Ruler2
            // 
            this.Ruler2.BackColor = System.Drawing.Color.Red;
            this.Ruler2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Ruler2.Location = new System.Drawing.Point(52, 275);
            this.Ruler2.Name = "Ruler2";
            this.Ruler2.Size = new System.Drawing.Size(280, 3);
            this.Ruler2.TabIndex = 5;
            // 
            // Re_Enter_Password
            // 
            this.Re_Enter_Password.AutoSize = true;
            this.Re_Enter_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Re_Enter_Password.ForeColor = System.Drawing.Color.Red;
            this.Re_Enter_Password.Location = new System.Drawing.Point(47, 232);
            this.Re_Enter_Password.Name = "Re_Enter_Password";
            this.Re_Enter_Password.Size = new System.Drawing.Size(160, 20);
            this.Re_Enter_Password.TabIndex = 6;
            this.Re_Enter_Password.Text = "Re-Enter Password:";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Email.ForeColor = System.Drawing.Color.Red;
            this.Email.Location = new System.Drawing.Point(48, 292);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(56, 20);
            this.Email.TabIndex = 7;
            this.Email.Text = "Email:";
            // 
            // Ruler3
            // 
            this.Ruler3.BackColor = System.Drawing.Color.Red;
            this.Ruler3.Location = new System.Drawing.Point(53, 337);
            this.Ruler3.Name = "Ruler3";
            this.Ruler3.Size = new System.Drawing.Size(280, 3);
            this.Ruler3.TabIndex = 8;
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_clear.ForeColor = System.Drawing.Color.Red;
            this.btn_clear.Location = new System.Drawing.Point(314, 3);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 32);
            this.btn_clear.TabIndex = 9;
            this.btn_clear.Text = "X";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_signup
            // 
            this.btn_signup.BackColor = System.Drawing.Color.Red;
            this.btn_signup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_signup.ForeColor = System.Drawing.Color.White;
            this.btn_signup.Location = new System.Drawing.Point(150, 418);
            this.btn_signup.Name = "btn_signup";
            this.btn_signup.Size = new System.Drawing.Size(98, 34);
            this.btn_signup.TabIndex = 10;
            this.btn_signup.Text = "Sign Up";
            this.btn_signup.UseVisualStyleBackColor = false;
            this.btn_signup.Click += new System.EventHandler(this.btn_signup_Click);
            this.btn_signup.MouseHover += new System.EventHandler(this.btn_signup_MouseHover);
            // 
            // checkBox
            // 
            this.checkBox.AutoSize = true;
            this.checkBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.checkBox.ForeColor = System.Drawing.Color.Red;
            this.checkBox.Location = new System.Drawing.Point(74, 369);
            this.checkBox.Name = "checkBox";
            this.checkBox.Size = new System.Drawing.Size(253, 24);
            this.checkBox.TabIndex = 11;
            this.checkBox.Text = "I Agree Terms and Conditions";
            this.checkBox.UseVisualStyleBackColor = true;
            // 
            // Txt_box
            // 
            this.Txt_box.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_box.Location = new System.Drawing.Point(51, 133);
            this.Txt_box.Name = "Txt_box";
            this.Txt_box.Size = new System.Drawing.Size(281, 22);
            this.Txt_box.TabIndex = 12;
            this.Txt_box.Text = "Full Name";
            // 
            // Txt_box1
            // 
            this.Txt_box1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_box1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_box1.Location = new System.Drawing.Point(52, 201);
            this.Txt_box1.Name = "Txt_box1";
            this.Txt_box1.Size = new System.Drawing.Size(200, 15);
            this.Txt_box1.TabIndex = 13;
            this.Txt_box1.Text = "Password";
            this.Txt_box1.UseSystemPasswordChar = true;
            // 
            // Txt_box2
            // 
            this.Txt_box2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_box2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_box2.Location = new System.Drawing.Point(53, 258);
            this.Txt_box2.Name = "Txt_box2";
            this.Txt_box2.Size = new System.Drawing.Size(200, 15);
            this.Txt_box2.TabIndex = 14;
            this.Txt_box2.Text = "Password";
            this.Txt_box2.UseSystemPasswordChar = true;
            // 
            // Txt_box3
            // 
            this.Txt_box3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_box3.Location = new System.Drawing.Point(52, 312);
            this.Txt_box3.Name = "Txt_box3";
            this.Txt_box3.Size = new System.Drawing.Size(280, 22);
            this.Txt_box3.TabIndex = 15;
            this.Txt_box3.Text = "@gmail.com";
            // 
            // Txt_box5
            // 
            this.Txt_box5.BackColor = System.Drawing.Color.Red;
            this.Txt_box5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_box5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Txt_box5.ForeColor = System.Drawing.Color.White;
            this.Txt_box5.Location = new System.Drawing.Point(86, 288);
            this.Txt_box5.Multiline = true;
            this.Txt_box5.Name = "Txt_box5";
            this.Txt_box5.Size = new System.Drawing.Size(219, 61);
            this.Txt_box5.TabIndex = 1;
            this.Txt_box5.Text = "We Create, We Design We Develop";
            this.Txt_box5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Txt_box5.TextChanged += new System.EventHandler(this.Txt_box5_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::sign_up_WindowformAPP.Properties.Resources.logo_RPITST_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(45, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(299, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Txt_box4
            // 
            this.Txt_box4.BackColor = System.Drawing.Color.Red;
            this.Txt_box4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Txt_box4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Txt_box4.ForeColor = System.Drawing.Color.White;
            this.Txt_box4.Location = new System.Drawing.Point(136, 250);
            this.Txt_box4.Name = "Txt_box4";
            this.Txt_box4.Size = new System.Drawing.Size(115, 23);
            this.Txt_box4.TabIndex = 4;
            this.Txt_box4.Text = "RPITST";
            this.Txt_box4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FormAPP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_left);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormAPP";
            this.panel_left.ResumeLayout(false);
            this.panel_left.PerformLayout();
            this.panel_right.ResumeLayout(false);
            this.panel_right.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.Panel panel_right;
        private System.Windows.Forms.Label UserName;
        private System.Windows.Forms.Label signUp;
        private System.Windows.Forms.Panel Ruler;
        private System.Windows.Forms.Panel Ruler1;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Label Re_Enter_Password;
        private System.Windows.Forms.Panel Ruler2;
        private System.Windows.Forms.Panel Ruler3;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.CheckBox checkBox;
        private System.Windows.Forms.Button btn_signup;
        private System.Windows.Forms.TextBox Txt_box;
        private System.Windows.Forms.TextBox Txt_box2;
        private System.Windows.Forms.TextBox Txt_box1;
        private System.Windows.Forms.TextBox Txt_box3;
        private System.Windows.Forms.TextBox Txt_box5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Txt_box4;
    }
}

