﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPITST_Dashboard
{
    public partial class Frm_Dashboard : Form
    {
        public Frm_Dashboard()
        {
            InitializeComponent();
        }

        private void Frm_Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void Btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Btn_Maximize_Click(object sender, EventArgs e)
        {
            this.WindowState |= FormWindowState.Maximized;
            Btn_Restore.Visible = true;
            Btn_Maximize.Visible = false;
        }

        private void Btn_Restore_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            Btn_Maximize.Visible = true;
            Btn_Restore.Visible = false;
        }

        private void btn_level_Click(object sender, EventArgs e)
        {
            AbriForm(new Frm_Level());  
        }
        private void AbriForm(object forms)
        {
            if (this.panel_Content.Controls.Count > 0) this.panel_Content.Controls.RemoveAt(0);

            Form frm = forms as Form;
            frm.TopLevel = false;
            frm.Dock = DockStyle.Fill;
            this.panel_Content.Controls.Add(frm);
            this.panel_Content.Tag = frm;
            frm.Show();
        }

        private void Btn_Menu_Click(object sender, EventArgs e)
        {
            if (this.panel_Menu.Width == 300)
            {
                Timer_Hide.Enabled = true;
            }
            else if (panel_Menu.Width == 20)
            {
                this.Timer_Show.Enabled = true;
            }
        }
        private void Timer_Show_Tick(object sender, EventArgs e)
        {
            if (panel_Menu.Width >= 300)
            {
                this.Timer_Show.Enabled = false;
            }
            else
            {
                this.panel_Menu.Width = panel_Menu.Width + 20;
            }
        }

        private void Timer_Hide_Tick(object sender, EventArgs e)
        {
            if (panel_Menu.Width < 30)
            {
                this.Timer_Hide.Enabled = false;

            }
            else
            {
                this.panel_Menu.Width = panel_Menu.Width - 30;
            }
        }

    }
}
